#!/bin/bash -e
source $commons/commons.sh

install_packages cifs-utils
