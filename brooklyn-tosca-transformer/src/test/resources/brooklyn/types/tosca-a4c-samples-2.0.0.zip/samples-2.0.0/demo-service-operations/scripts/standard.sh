#!/bin/bash

echo "Executing $OPERATION on $IP_ADDR"

export TYPE=Standard