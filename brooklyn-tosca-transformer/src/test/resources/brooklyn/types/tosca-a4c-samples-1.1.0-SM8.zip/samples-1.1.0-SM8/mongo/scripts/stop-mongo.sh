#!/bin/bash

echo "BEGIN mongo start"

echo "service mongo stop"

sudo service mongod stop

echo "END service mongo stop"

