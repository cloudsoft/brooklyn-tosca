#!/bin/bash
sudo bash -c "echo '$REGISTRY_HOST a4c_registry' >> /etc/hosts"