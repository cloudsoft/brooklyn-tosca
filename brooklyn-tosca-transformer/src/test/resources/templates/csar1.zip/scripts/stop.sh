kill -9 `cat ${PID_FILE:-pid.txt}`

