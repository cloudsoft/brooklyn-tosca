
Components
==========

Git

Version
=======

Latest

Details
=======

- Installed with apt-get
- Requirements : Debian system
