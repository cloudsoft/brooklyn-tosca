
This component will expose some plugin sources zip and plugin.yaml and will also :

- upload a plugin to cfy
- change A4C orchestrator config (locations of orchestrator)
