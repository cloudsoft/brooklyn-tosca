
Components
==========

Apache2

Version
=======

2.4

Details
=======

- Installed with apt-get on Ubuntu OS (tested on Ubuntu 12.04 and 14.04)
- Default port : 80
