# this folder is Deprecated, all components should be pushed to https://github.com/alien4cloud/csar-public-library/tree/develop/org/alien4cloud

- types.yml at root (for build compatibility)
- name csar with the full path
- prefix all types in this csar with this path
- all public types (services, capabilities) should be in a pub package
- a pub package should not import a non pub package
- should not import from external except normative types et extended types
