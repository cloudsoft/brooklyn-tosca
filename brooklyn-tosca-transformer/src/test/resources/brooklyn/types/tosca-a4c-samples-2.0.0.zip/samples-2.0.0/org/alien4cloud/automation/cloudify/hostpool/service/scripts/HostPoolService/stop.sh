#!/bin/bash -e

sudo ~/cloudify-hostpool-service-pkg/bin/stop.sh
