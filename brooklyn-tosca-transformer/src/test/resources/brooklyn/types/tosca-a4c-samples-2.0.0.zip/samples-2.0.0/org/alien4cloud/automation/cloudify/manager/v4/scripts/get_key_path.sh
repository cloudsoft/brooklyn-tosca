#!/bin/bash

HOME_DIR=~
export KEY_FILE_PATH="$HOME_DIR/cfy_keys/$SSH_KEY_FILENAME"
