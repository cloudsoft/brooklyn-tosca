#!/bin/bash -e

# Install Hostpool Service
sudo ~/cloudify-hostpool-service-pkg/bin/uninstall.sh
