#!/bin/bash -e
sudo cp -R -f $php_scripts/* /var/www/
