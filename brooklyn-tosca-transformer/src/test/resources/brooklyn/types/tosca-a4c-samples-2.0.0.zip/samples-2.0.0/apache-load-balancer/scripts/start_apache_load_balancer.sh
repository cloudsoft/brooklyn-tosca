#!/bin/bash -e

sudo /etc/init.d/apache2 start