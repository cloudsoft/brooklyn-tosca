#!/bin/bash -e


echo "#####################################"
echo "pre_configure_source"
echo "YoLo3"
echo "#####################################"

echo "Context: $context"
echo "SOURCE_INSTANCE: $SOURCE_INSTANCE"
echo "TARGET_INSTANCE: $TARGET_INSTANCE"
echo "service_host_uname: <$service_host_uname>"
echo "service_protocol: <$service_protocol>"
echo "service_port: <$service_port>"
echo "service_ip_address: <$service_ip_address>"

echo "#####################################"
echo "#####################################"
