
Components
==========

PHP

Version
=======

5.5

Details
=======

- Installed with apt-get on Ubuntu OS (tested on Ubuntu 12.04 and 14.04)
