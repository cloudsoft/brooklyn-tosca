
Components
==========

MySQL RDBMS

Version of MySQL
=======

5.5

Version of component
=======

2.0.0 (tested on Ubuntu 12.04 and 14.04)

Defails
=======

- Installed with apt-get on Ubuntu OS
- The database will store data in a specified mounted volume (property : storage_path)
- The database be available on specified port (property : port, default is 3306)
