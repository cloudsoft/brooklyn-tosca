tosca-normative-types
=====================

This repository contains tosca Simple Profile in YAML normative types as supported in Alien 4 Cloud.

Supported version is close from current TOSCA Yaml specification working drafts but may be slightly different as the specification is still being updated.
