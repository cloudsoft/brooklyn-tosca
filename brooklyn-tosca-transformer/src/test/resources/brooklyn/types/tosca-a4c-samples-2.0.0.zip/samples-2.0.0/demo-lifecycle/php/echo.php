<?php
header('Content-Type: text/plain');
echo "OK";
?>
