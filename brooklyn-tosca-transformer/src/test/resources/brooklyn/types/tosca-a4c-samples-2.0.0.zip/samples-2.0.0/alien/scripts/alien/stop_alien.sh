#!/bin/bash -e
sudo /etc/init.d/$service stop
