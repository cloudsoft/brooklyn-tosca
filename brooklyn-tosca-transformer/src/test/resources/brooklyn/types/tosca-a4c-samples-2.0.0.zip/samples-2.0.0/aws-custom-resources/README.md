These types can be used to illustrate the usage of custom types to provision on-demand resources on AWS.

Need [aws cli](http://docs.aws.amazon.com/cli/latest/userguide/installing.html) to be installed on the orchestrator's 'manager'.
You must provide AWS credentials (keys and secrets) as property values.
