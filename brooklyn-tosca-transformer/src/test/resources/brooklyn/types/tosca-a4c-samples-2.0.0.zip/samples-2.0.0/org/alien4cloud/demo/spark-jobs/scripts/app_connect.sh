#!/bin/bash

mkdir -p /tmp/a4c/work/${SOURCE_NODE}/${SOURCE_INSTANCE}/SparkAppDependency
echo "${TARGET_INSTANCE}" > /tmp/a4c/work/${SOURCE_NODE}/${SOURCE_INSTANCE}/SparkAppDependency/TARGET_INSTANCE
