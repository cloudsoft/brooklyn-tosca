
Components
==========

MySQL RDBMS

Version
=======

5.5

Defails
=======

- Installed with apt-get on Ubuntu OS
- The database will store data in a specified mounted volume (property : storage_path)
- The database be available on specified port (property : port, default is 3306)
