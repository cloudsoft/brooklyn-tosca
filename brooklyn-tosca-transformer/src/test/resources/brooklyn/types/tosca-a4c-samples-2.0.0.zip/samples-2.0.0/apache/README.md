
Components
==========

Apache2

Version of apache
=======

2.4

Version of component
=======

2.0.0 (tested on Ubuntu 12.04 and 14.04)

Details
=======

- Installed with apt-get on Ubuntu OS (tested on Ubuntu 12.04 and 14.04)
- Default port : 80
