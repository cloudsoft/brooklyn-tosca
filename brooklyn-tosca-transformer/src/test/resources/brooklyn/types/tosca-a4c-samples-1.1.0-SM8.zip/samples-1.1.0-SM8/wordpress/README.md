
Components
==========

Wordpress

Details
=======

- Deploy a Wordpress on Ubuntu OS (tested on Ubuntu 12.04 and 14.04)
- Use **unzip**, install it with apt-get if not present
- Use the config of Mysql node
- Install php5-mysql module
