#!/bin/bash

sudo kill -9 $(cat /var/run/docker-bootstrap.pid)