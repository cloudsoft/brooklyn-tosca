      # create the web page to serve
      cat > index.html << EOF
      
      Hello world. This is the test for today.
      <p>
      I am a TOSCA example.
      <p>
      Created at: `date`
      <p>
      
      EOF

