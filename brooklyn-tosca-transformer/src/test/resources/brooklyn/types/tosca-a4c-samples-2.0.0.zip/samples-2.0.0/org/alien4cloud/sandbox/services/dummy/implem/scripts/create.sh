#!/bin/bash -e

export HOST_UNAME=$(uname -a)
